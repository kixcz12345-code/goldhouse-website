import React, { useState } from "react";
import {
  Calendar,
  MapPin,
  Users,
  Building,
  Hammer,
  Construction,
  Award,
  Phone,
  Mail,
  Map,
  Menu,
  X,
} from "lucide-react";

const App = () => {
  const [activeTab, setActiveTab] = useState("services"); // Главная — услуги
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Переключение на главную (услуги) по клику на логотип
  const handleGoToHome = () => {
    setActiveTab("services");
    setMobileMenuOpen(false);
    setTimeout(() => {
      const servicesSection = document.getElementById("services");
      if (servicesSection) {
        servicesSection.scrollIntoView({ behavior: "smooth" });
      }
    }, 100);
  };

  const handleOpenApplication = () => {
    setActiveTab("contact");
    setMobileMenuOpen(false);
    setTimeout(() => {
      const contactSection = document.getElementById("contact");
      if (contactSection) {
        contactSection.scrollIntoView({ behavior: "smooth" });
      }
    }, 100);
  };

  const services = [
    {
      icon: Hammer,
      title: "Демонтажные работы",
      description:
        "Полный комплекс демонтажных работ с соблюдением всех норм безопасности и экологических стандартов.",
      details: [
        "Снос зданий и сооружений",
        "Демонтаж перекрытий и стен",
        "Утилизация строительных отходов",
        "Аварийные демонтажные работы",
      ],
    },
    {
      icon: Construction,
      title: "Монтажные работы",
      description:
        "Профессиональный монтаж конструкций любой сложности с использованием современного оборудования.",
      details: [
        "Монтаж металлоконструкций",
        "Установка инженерных систем",
        "Монтаж фасадных систем",
        "Сборка модульных конструкций",
      ],
    },
    {
      icon: Building,
      title: "Реконструкция объектов",
      description:
        "Комплексная реконструкция зданий и сооружений с полной адаптацией под современные требования.",
      details: [
        "Реконструкция промышленных объектов",
        "Модернизация жилых зданий",
        "Реставрация исторических зданий",
        "Перепланировка помещений",
      ],
    },
    {
      icon: Map,
      title: "Благоустройство территорий",
      description:
        "Комплексное благоустройство прилегающих территорий с созданием комфортной и функциональной среды.",
      details: [
        "Озеленение и ландшафтный дизайн",
        "Укладка тротуарной плитки",
        "Монтаж малых архитектурных форм",
        "Освещение территорий",
      ],
    },
  ];

  const projects = [
    {
      id: 1,
      title: "Реконструкция ТЦ 'Центральный'",
      type: "Реконструкция",
      location: "Москва",
      image: "https://placehold.co/400x250/1a365d/ffffff?text=ТЦ+Центральный",
      description:
        "Полная реконструкция торгового центра с заменой инженерных систем и фасадов",
    },
    {
      id: 2,
      title: "Демонтаж промышленного комплекса",
      type: "Демонтаж",
      location: "Санкт-Петербург",
      image:
        "https://placehold.co/400x250/2d3748/ffffff?text=Промышленный+Комплекс",
      description:
        "Безопасный демонтаж промышленного комплекса площадью 15,000 м²",
    },
    {
      id: 3,
      title: "Благоустройство жилого комплекса",
      type: "Благоустройство",
      location: "Екатеринбург",
      image: "https://placehold.co/400x250/2c5282/ffffff?text=ЖК+Зеленый+Парк",
      description:
        "Комплексное благоустройство территории жилого комплекса на 800 квартир",
    },
    {
      id: 4,
      title: "Монтаж торгового павильона",
      type: "Монтаж",
      location: "Казань",
      image:
        "https://placehold.co/400x250/4a5568/ffffff?text=Торговый+Павильон",
      description:
        "Быстрый монтаж модульного торгового павильона за 14 рабочих дней",
    },
  ];

  const team = [
    {
      name: "Иван Витальевич",
      role: "Производственный Директор",
      experience: "8 лет опыта",
      image: "https://placehold.co/200x200/4a5568/ffffff?text=И.П.",
    },
    {
      name: "Никита Сергеевич",
      role: "Технический Директор",
      experience: "8 лет опыта",
      image: "https://placehold.co/200x200/2d3748/ffffff?text=Н.С.",
    },
    {
      name: "Вакантно",
      role: "Руководитель проектов",
      experience: "- лет опыта",
      image: "https://placehold.co/200x200/2c5282/ffffff?text=..",
    },
    {
      name: "Вакантно",
      role: "Инженер-конструктор",
      experience: "- лет опыта",
      image: "https://placehold.co/200x200/1a365d/ffffff?text=..",
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Логотип + название — клик ведёт на главную (services) */}
            <div
              onClick={handleGoToHome}
              className="flex items-center space-x-3 cursor-pointer"
            >
              <div className="w-10 h-10 bg-gradient-to-r from-amber-600 to-amber-800 rounded-lg flex items-center justify-center">
                <Building className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">GoldHouse</h1>
                <p className="text-xs text-gray-500">
                  Субподрядные строительные работы
                </p>
              </div>
            </div>

            {/* Мобильное меню — видно только на малых экранах */}
            <div className="md:hidden flex items-center">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="text-gray-700 hover:text-amber-600"
              >
                {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-8">
              <button
                onClick={() => {
                  setActiveTab("services");
                  setMobileMenuOpen(false);
                }}
                className={`text-sm font-medium ${
                  activeTab === "services"
                    ? "text-amber-600"
                    : "text-gray-700 hover:text-amber-600"
                }`}
              >
                Услуги
              </button>
              <button
                onClick={() => {
                  setActiveTab("about");
                  setMobileMenuOpen(false);
                }}
                className={`text-sm font-medium ${
                  activeTab === "about"
                    ? "text-amber-600"
                    : "text-gray-700 hover:text-amber-600"
                }`}
              >
                О компании
              </button>
              <button
                onClick={() => {
                  setActiveTab("contact");
                  setMobileMenuOpen(false);
                }}
                className={`text-sm font-medium ${
                  activeTab === "contact"
                    ? "text-amber-600"
                    : "text-gray-700 hover:text-amber-600"
                }`}
              >
                Контакты
              </button>
            </nav>

            {/* Кнопка заявки — всегда видна */}
            <button
              onClick={handleOpenApplication}
              className="hidden md:block bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition-colors font-medium"
            >
              Заполнить заявку
            </button>
          </div>

          {/* Mobile Navigation Dropdown */}
          {mobileMenuOpen && (
            <div className="md:hidden py-4 border-t border-gray-200">
              <div className="flex flex-col space-y-3">
                <button
                  onClick={() => {
                    setActiveTab("services");
                    setMobileMenuOpen(false);
                  }}
                  className={`text-left text-sm font-medium px-2 py-1 rounded ${
                    activeTab === "services"
                      ? "text-amber-600 bg-amber-50"
                      : "text-gray-700 hover:text-amber-600"
                  }`}
                >
                  Услуги
                </button>
                <button
                  onClick={() => {
                    setActiveTab("about");
                    setMobileMenuOpen(false);
                  }}
                  className={`text-left text-sm font-medium px-2 py-1 rounded ${
                    activeTab === "about"
                      ? "text-amber-600 bg-amber-50"
                      : "text-gray-700 hover:text-amber-600"
                  }`}
                >
                  О компании
                </button>
                <button
                  onClick={() => {
                    setActiveTab("contact");
                    setMobileMenuOpen(false);
                  }}
                  className={`text-left text-sm font-medium px-2 py-1 rounded ${
                    activeTab === "contact"
                      ? "text-amber-600 bg-amber-50"
                      : "text-gray-700 hover:text-amber-600"
                  }`}
                >
                  Контакты
                </button>
                <button
                  onClick={handleOpenApplication}
                  className="mt-2 bg-amber-600 text-white px-4 py-2 rounded-lg font-medium text-center"
                >
                  Заполнить заявку
                </button>
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-amber-700 via-amber-800 to-gray-900 text-white py-16 sm:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-4 sm:mb-6">
            Профессиональные субподрядные
            <span className="block text-amber-300 mt-1">
              строительные работы
            </span>
          </h2>
          <p className="text-lg sm:text-xl md:text-2xl text-amber-100 max-w-3xl mx-auto mb-6 sm:mb-8 px-2">
            Демонтаж, монтаж, реконструкция и благоустройство — комплексные
            решения для подрядчиков и застройщиков
          </p>
          <div className="flex flex-wrap justify-center gap-4 sm:gap-6 text-center px-2">
            <div className="flex items-center space-x-1 sm:space-x-2">
              <Hammer className="h-5 w-5 sm:h-6 sm:w-6" />
              <span className="text-sm sm:text-base">8+ лет опыта</span>
            </div>
            <div className="flex items-center space-x-1 sm:space-x-2">
              <Users className="h-5 w-5 sm:h-6 sm:w-6" />
              <span className="text-sm sm:text-base">35+ проектов</span>
            </div>
            <div className="flex items-center space-x-1 sm:space-x-2">
              <Award className="h-5 w-5 sm:h-6 sm:w-6" />
              <span className="text-sm sm:text-base">
                Сертифицированное качество
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Conditional Rendering by Tab */}
      {activeTab === "services" && (
        <section id="services" className="py-12 sm:py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-8 sm:mb-12">
              <h3 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-3 sm:mb-4">
                Наши услуги
              </h3>
              <p className="text-base sm:text-lg text-gray-600 max-w-2xl mx-auto px-2">
                Полный спектр субподрядных работ для подрядных организаций и
                застройщиков
              </p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8 px-2">
              {services.map((service, index) => (
                <div
                  key={index}
                  className="bg-gray-50 rounded-xl p-5 sm:p-6 hover:shadow-lg transition-shadow border border-gray-100"
                >
                  <div className="w-10 h-10 sm:w-12 sm:h-12 bg-amber-100 rounded-lg flex items-center justify-center mb-3 sm:mb-4">
                    <service.icon className="h-5 w-5 sm:h-6 sm:w-6 text-amber-600" />
                  </div>
                  <h4 className="text-lg sm:text-xl font-semibold text-gray-900 mb-2 sm:mb-3">
                    {service.title}
                  </h4>
                  <p className="text-sm sm:text-base text-gray-600 mb-3 sm:mb-4">
                    {service.description}
                  </p>
                  <ul className="space-y-1.5">
                    {service.details.map((detail, i) => (
                      <li
                        key={i}
                        className="flex items-start text-sm text-gray-700"
                      >
                        <div className="w-1.5 h-1.5 sm:w-2 sm:h-2 bg-amber-600 rounded-full mt-1.5 mr-2 flex-shrink-0"></div>
                        <span>{detail}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {activeTab === "about" && (
        <section id="about" className="py-12 sm:py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 sm:gap-12 items-center px-2">
              <div>
                <h3 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-4 sm:mb-6">
                  О компании GoldHouse
                </h3>
                <p className="text-base sm:text-lg text-gray-600 mb-6">
                  Мы специализируемся на предоставлении субподрядных
                  строительных услуг для подрядных организаций, застройщиков и
                  девелоперов. Наша команда профессионалов выполняет работы
                  любой сложности с соблюдением сроков, бюджета и высочайших
                  стандартов качества.
                </p>
                <div className="grid grid-cols-2 gap-4 sm:gap-6 mb-6">
                  <div className="text-center">
                    <div className="text-2xl sm:text-3xl font-bold text-amber-600 mb-1 sm:mb-2">
                      8+
                    </div>
                    <div className="text-sm text-gray-600">Лет опыта</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl sm:text-3xl font-bold text-amber-600 mb-1 sm:mb-2">
                      35+
                    </div>
                    <div className="text-sm text-gray-600">Проектов</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl sm:text-3xl font-bold text-amber-600 mb-1 sm:mb-2">
                      20+
                    </div>
                    <div className="text-sm text-gray-600">Сотрудников</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl sm:text-3xl font-bold text-amber-600 mb-1 sm:mb-2">
                      92%
                    </div>
                    <div className="text-sm text-gray-600">Клиентов</div>
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {team.map((member, index) => (
                  <div
                    key={index}
                    className="bg-gray-50 rounded-lg p-4 text-center"
                  >
                    <img
                      src={member.image.trim()}
                      alt={member.name}
                      className="w-16 h-16 sm:w-20 sm:h-20 rounded-full mx-auto mb-2 sm:mb-3 object-cover"
                    />
                    <h4 className="font-semibold text-gray-900 text-sm sm:text-base">
                      {member.name}
                    </h4>
                    <p className="text-xs sm:text-sm text-amber-600">
                      {member.role}
                    </p>
                    <p className="text-xs text-gray-500">{member.experience}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>
      )}

      {activeTab === "contact" && (
        <section id="contact" className="py-12 sm:py-16 bg-gray-900 text-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 sm:gap-12 px-2">
              <div>
                <h3 className="text-2xl sm:text-3xl font-bold mb-4 sm:mb-6">
                  Свяжитесь с нами
                </h3>
                <p className="text-gray-300 mb-6 sm:mb-8">
                  Готовы обсудить ваш проект? Наши специалисты проконсультируют
                  вас и подготовят коммерческое предложение.
                </p>
                <div className="space-y-3 sm:space-y-4">
                  <div className="flex items-start">
                    <Phone className="h-5 w-5 text-amber-400 mt-0.5 mr-3 flex-shrink-0" />
                    <span className="text-base">
                      +7 (951) 850-01-05
                      <br />
                      +7 (960) 104-15-73
                    </span>
                  </div>
                  <div className="flex items-center">
                    <Mail className="h-5 w-5 text-amber-400 mr-3 flex-shrink-0" />
                    <span className="text-base">goldhouseTM@yandex.ru</span>
                  </div>
                  <div className="flex items-center">
                    <MapPin className="h-5 w-5 text-amber-400 mr-3 flex-shrink-0" />
                    <span className="text-base">г. Воронеж</span>
                  </div>
                  <div className="flex items-center">
                    <Calendar className="h-5 w-5 text-amber-400 mr-3 flex-shrink-0" />
                    <span className="text-base">Пн-Пт: 9:00-18:00</span>
                  </div>
                </div>
              </div>
              <div className="bg-gray-800 rounded-xl p-6 sm:p-8">
                <form
                  action="https://formspree.io/f/xpwovoyj"
                  method="POST"
                  className="space-y-5"
                >
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Ваше имя
                    </label>
                    <input
                      type="text"
                      name="name"
                      required
                      className="w-full px-3 py-2.5 sm:px-4 sm:py-3 bg-gray-700 border border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent text-white text-sm sm:text-base"
                      placeholder="Введите ваше имя"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Телефон
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      required
                      className="w-full px-3 py-2.5 sm:px-4 sm:py-3 bg-gray-700 border border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent text-white text-sm sm:text-base"
                      placeholder="+7 (___) ___-__-__"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Тип работ
                    </label>
                    <select
                      name="serviceType"
                      className="w-full px-3 py-2.5 sm:px-4 sm:py-3 bg-gray-700 border border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent text-white text-sm sm:text-base"
                    >
                      <option value="">Выберите тип работ</option>
                      <option value="Демонтажные работы">
                        Демонтажные работы
                      </option>
                      <option value="Монтажные работы">Монтажные работы</option>
                      <option value="Реконструкция">Реконструкция</option>
                      <option value="Благоустройство территорий">
                        Благоустройство территорий
                      </option>
                      <option value="Комплексные работы">
                        Комплексные работы
                      </option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Сообщение
                    </label>
                    <textarea
                      name="message"
                      rows="3"
                      className="w-full px-3 py-2.5 sm:px-4 sm:py-3 bg-gray-700 border border-gray-600 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent text-white text-sm sm:text-base"
                      placeholder="Опишите ваш проект..."
                    ></textarea>
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-amber-600 text-white py-2.5 sm:py-3 px-4 rounded-lg hover:bg-amber-700 transition-colors font-medium text-sm sm:text-base"
                  >
                    Отправить заявку
                  </button>
                </form>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-6 sm:py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            {/* Логотип в футере — тоже ведёт на главную */}
            <div
              onClick={handleGoToHome}
              className="flex items-center space-x-3 cursor-pointer"
            >
              <div className="w-8 h-8 bg-gradient-to-r from-amber-600 to-amber-800 rounded-lg flex items-center justify-center">
                <Building className="h-5 w-5 text-white" />
              </div>
              <div>
                <h4 className="font-bold">GoldHouse</h4>
                <p className="text-xs sm:text-sm text-gray-400">
                  Субподрядные строительные работы
                </p>
              </div>
            </div>
            <p className="text-center text-xs sm:text-sm text-gray-400">
              &copy; 2025 GoldHouse. Все права защищены.
            </p>
            <button
              onClick={handleOpenApplication}
              className="bg-amber-600 text-white px-4 py-1.5 sm:px-6 sm:py-2 rounded-lg hover:bg-amber-700 transition-colors font-medium text-sm"
            >
              Заполнить заявку
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
